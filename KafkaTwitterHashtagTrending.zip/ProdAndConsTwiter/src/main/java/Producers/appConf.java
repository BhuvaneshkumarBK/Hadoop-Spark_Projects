package Producers;

public class appConf {
    public static String clienID="twitterStreaming";
    public static String BOOTSTRAP_SERVERS_CONFIG="localhost:9092";
    public static String TRANSACTIONAL_ID_CONFIG="T1";
    public static String topic="TTTEx";
    public static String schema="http://localhost:8081";
    public static String stroeID="keyStore";
    public static Object clienIDJuit="twitterJunit";
    public static String outTopic= "out";
}
